#include "main.h"
#include "gui/gui.h"
#include "game/game.h"
#include "net/netgame.h"
#include "settings.h"
#include "dialog.h"
#include "spawnscreen.h"
#include "Cyuana.h"
#include "chatwindow.h"
#include "scoreboard.h"
#include "keyboard.h"
#include "consolegui.h"
#include "button.h"

extern CGUI* pGUI;
extern CGame* pGame;
extern CNetGame* pNetGame;
extern CSettings* pSettings;
extern CDialogWindow* pDialogWindow;
extern CSpawnScreen* pSpawnScreen;
extern CChatWindow* pChatWindow;
extern CScoreBoard* pScoreBoard;
extern CKeyBoard* pKeyBoard;
extern CConsoleGUI* pConsoleGUI;
extern CButton* pButton;


CExtraKeyBoard::CExtraKeyBoard() {
	m_bIsActive = false;
	m_bIsItemShow = false;
}

CExtraKeyBoard::~CExtraKeyBoard() { }

void CExtraKeyBoard::Show(bool bShow) {
	m_bIsActive = bShow;
}

void CExtraKeyBoard::Render() 
{
	if (!m_bIsActive || pSpawnScreen->GetState() || pKeyBoard->IsOpen() || pDialogWindow->m_bIsActive) {
		return;
	}
	//==============================================================================
	AltTexture 			= (RwTexture*)LoadTextureFromDB("samp", "alt");
	Ctrltexture 		= (RwTexture*)LoadTextureFromDB("samp", "ctrl");
	Tabtexture 			= (RwTexture*)LoadTextureFromDB("samp", "tab");
	Tabxtexture 		= (RwTexture*)LoadTextureFromDB("samp", "tabx");
	Twotexture 			= (RwTexture*)LoadTextureFromDB("samp", "two");
	Ftexture 			= (RwTexture*)LoadTextureFromDB("samp", "f");
	Htexture 			= (RwTexture*)LoadTextureFromDB("samp", "h");
	Ytexture 			= (RwTexture*)LoadTextureFromDB("samp", "y");
	Ntexture 			= (RwTexture*)LoadTextureFromDB("samp", "n");
	Gtexture 			= (RwTexture*)LoadTextureFromDB("samp", "G");
	Ctexture 			= (RwTexture*)LoadTextureFromDB("samp", "c");
	ScrlRtexture 		= (RwTexture*)LoadTextureFromDB("samp", "scroll_r");
	ScrlLtexture 		= (RwTexture*)LoadTextureFromDB("samp", "scroll_l");
	//==============================================================================

	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 8));
	ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign, ImVec2(0.5f, 0.5f));
	//============================COLORS============================================
	ImGui::PushStyleColor(ImGuiCol_Button, ImColor(0x66, 0x00, 0xCC).Value);
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImColor(0x98, 0x32, 0xFF).Value);
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImColor(0x98, 0x32, 0xFF).Value);;
	//==============================================================================
	CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
	if (pPlayerPed) {
		ImGuiIO& io = ImGui::GetIO();

		ImGui::GetStyle().ButtonTextAlign = ImVec2(0.5f, 0.5f);
		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 8));//8.8
		ImGuiStyle style;
		style.FrameBorderSize = ImGui::GetStyle().FrameBorderSize;
		ImGui::GetStyle().FrameBorderSize = 0.0f;
		//===============================================================================================================
		ImVec2 vecButSize = ImVec2(ImGui::GetFontSize() * 3.0, ImGui::GetFontSize() * 2.0);//3.5 //2.5
		ImGui::SetNextWindowPos(ImVec2(2.0f, (io.DisplaySize.y / 3) - (vecButSize.x / 2) + io.DisplaySize.y / 30));
		//===============================================================================================================
		
		ImGui::Begin("Neckeys", nullptr, 
			ImGuiWindowFlags_NoTitleBar | 
			ImGuiWindowFlags_NoBackground | 
			ImGuiWindowFlags_NoMove | 
			ImGuiWindowFlags_NoResize | 
			ImGuiWindowFlags_NoScrollbar | 
			ImGuiWindowFlags_NoSavedSettings);

		m_fButWidth 		= ImGui::CalcTextSize("QWERT").x; 
		m_fButHeight 		= ImGui::CalcTextSize("QW").x; 
		ImVec2 vecButSquare = ImVec2(ImGui::GetFontSize() * 3.0, ImGui::GetFontSize() * 2.0);
		
		//===========================================================================================================
		if (m_bIsItemShow) 
		{
			if (ImGui::ImageButton((ImTextureID)ScrlLtexture->raster, vecButSize)) m_bIsItemShow = false; //<<<
		}
		else 
		{
			if (ImGui::ImageButton((ImTextureID)ScrlRtexture->raster, vecButSize)) m_bIsItemShow = true; //>>>
		}
		//===========================================================================================================
		ImGui::SameLine();
		if(m_bIsItemShow)
		{
			if (!pScoreBoard->m_bToggle)
			{
				if (ImGui::ImageButton((ImTextureID)Tabtexture->raster, vecButSize)) 	//pScoreBoard->m_bToggle = true; pScoreBoard->Toggle(); //Tab
				{
				pScoreBoard->m_bToggle = true;
				pScoreBoard->Toggle();
				}
			}
			else 
			{
				if (ImGui::ImageButton((ImTextureID)Tabxtexture->raster, vecButSize)) 	//pScoreBoard->m_bToggle = false; pScoreBoard->Toggle(); //Tab
				//if (ImGui::Button("X", vecButSize))
				{
				pScoreBoard->m_bToggle = false;
				pScoreBoard->Toggle();
				}
			}
			ImGui::SameLine();
			if(m_bIsItemShow)
			{
				if (ImGui::ImageButton((ImTextureID)AltTexture->raster, vecButSize)) 	LocalPlayerKeys.bKeys[ePadKeys::KEY_WALK] = true; //Alt
				ImGui::SameLine();
				if (ImGui::ImageButton((ImTextureID)Ctrltexture->raster, vecButSize)) 	LocalPlayerKeys.bKeys[ePadKeys::KEY_ACTION] = true; // CTRL
				ImGui::SameLine();
				if (ImGui::ImageButton((ImTextureID)Ftexture->raster, vecButSize)) 		LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK] = true; //F
				ImGui::SameLine();
				if (ImGui::ImageButton((ImTextureID)Htexture->raster, vecButSize)) 		LocalPlayerKeys.bKeys[ePadKeys::KEY_CTRL_BACK] = true; //H
				ImGui::SameLine();
				if (ImGui::ImageButton((ImTextureID)Ytexture->raster, vecButSize)) 		LocalPlayerKeys.bKeys[ePadKeys::KEY_YES] = true; //Y
				ImGui::SameLine();
				if (ImGui::ImageButton((ImTextureID)Ntexture->raster, vecButSize)) 		LocalPlayerKeys.bKeys[ePadKeys::KEY_NO] = true; //N
				ImGui::SameLine();
				if (ImGui::ImageButton((ImTextureID)Ctexture->raster, vecButSize)) 		LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH] = true; //C
				ImGui::SameLine();
				if (ImGui::ImageButton((ImTextureID)Twotexture->raster, vecButSize)) 	LocalPlayerKeys.bKeys[ePadKeys::KEY_SUBMISSION] = true; //2
				ImGui::SameLine(0, 5);
			}
		}
		ImGui::SetWindowSize(ImVec2(-1, -1));

		ImVec2 size = ImGui::GetWindowSize();
		ImGui::GetStyle().FrameBorderSize = style.FrameBorderSize;
		ImGui::SetWindowPos(ImVec2(pGUI->ScaleX(10), pGUI->ScaleY(345)));
		ImGui::End();
	}
	ImGui::PopStyleVar(2);
	ImGui::PopStyleColor(3);
	return;
}