#pragma once 
#include "game/RW/RenderWare.h"
class CVoiceChat
{
public:
	CVoiceChat();
	~CVoiceChat();
public:
	RwTexture* pVoiceTexture = nullptr;
	void RenderVoiceButton();
	void InitChat();
	void Process();
private:
	/*--  Coming soon u know-- */
};