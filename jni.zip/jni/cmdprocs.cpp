#include "main.h"
#include "cmdprocs.h"
#include "game/game.h"
#include "net/netgame.h"
#include "chatwindow.h"

extern CChatWindow *pChatWindow;
extern CGame *pGame;
extern CNetGame *pNetGame;
