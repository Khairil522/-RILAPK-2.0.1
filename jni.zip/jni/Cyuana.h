#pragma once

class CExtraKeyBoard
{
public:
	CExtraKeyBoard();
	~CExtraKeyBoard();

	void Render();
	void Clear();
	void Show(bool bShow);
	// texture
	RwTexture* AltTexture = nullptr;
	RwTexture* Ctrltexture = nullptr;
	RwTexture* Tabtexture = nullptr;
	RwTexture* Tabxtexture = nullptr;
	RwTexture* Ftexture = nullptr; 
	RwTexture* Htexture = nullptr;
	RwTexture* Ytexture = nullptr;
	RwTexture* Ntexture = nullptr;
	RwTexture* Gtexture = nullptr;
	RwTexture* Ctexture = nullptr;
	RwTexture* Twotexture = nullptr;
	RwTexture* ScrlRtexture = nullptr;
	RwTexture* ScrlLtexture = nullptr;

private:
	float m_fButWidth;
	float m_fButHeight;
	bool m_bIsItemShow;
	bool m_bIsActive;
};
