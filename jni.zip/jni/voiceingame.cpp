#include "voiceingame.h"
#include "main.h"
#include "gui/gui.h"
#include "game/game.h"
#include "net/netgame.h"
#include "settings.h"
#include "dialog.h"
#include "spawnscreen.h"
#include "GButton.h"
#include "chatwindow.h"
#include "scoreboard.h"
#include "keyboard.h"
extern CGUI* pGUI;
extern CGame* pGame;
extern CNetGame* pNetGame;
extern CSettings* pSettings;
extern CDialogWindow* pDialogWindow;
extern CSpawnScreen* pSpawnScreen;
extern CChatWindow* pChatWindow;
extern CScoreBoard* pScoreBoard;
extern CKeyBoard* pKeyBoard;



///////////////////////////////

CVoiceChat::CVoiceChat()
{
	// const
}

CVoiceChat::~CVoiceChat()
{
	// dest
}

void CVoiceChat::InitChat()
{
}

void CVoiceChat::Process()
{
	//comingsoon
}

void CVoiceChat::RenderVoiceButton()
{
	pVoiceTexture = (RwTexture*)LoadTextureFromDB("samp", "voice"); 
	if (pDialogWindow->m_bIsActive || pScoreBoard->m_bToggle || pKeyBoard->IsOpen()) return;

	if (!pNetGame) return;

	ImGuiIO& io = ImGui::GetIO();

	ImGui::PushStyleColor(ImGuiCol_Button, (ImVec4)ImColor(0x00, 0x00, 0x00, 0x00).Value);
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, (ImVec4)ImColor(0x00, 0x00, 0x00, 0x00).Value);
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, (ImVec4)ImColor(0x00, 0x00, 0x00, 0x00).Value);

	ImGuiStyle style;
	style.FrameBorderSize = ImGui::GetStyle().FrameBorderSize;
	ImGui::GetStyle().FrameBorderSize = 0.0f;

	ImGui::Begin("VoiceChatButton", nullptr,
		ImGuiWindowFlags_NoTitleBar |
		ImGuiWindowFlags_NoBackground |
		ImGuiWindowFlags_NoMove |
		ImGuiWindowFlags_NoResize |
		ImGuiWindowFlags_NoScrollbar |
		ImGuiWindowFlags_NoSavedSettings);
	ImVec2 VecButtonSize = ImVec2(ImGui::GetFontSize() * 5 + 5.0f, ImGui::GetFontSize() * 5);
	// Menemukan Down
	CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
	if(pPlayerPed) // Jika ditemukan down
	{
		// - - - Tombol dimatikan - - - di gui.cpp. - - - //
		if(ImGui::ImageButton((ImTextureID)pVoiceTexture->raster,VecButtonSize))
			{
				pChatWindow->AddDebugMessage("VOICE");
				pChatWindow->AddDebugMessage("Commingsoon");
			//	Process();
			}
		
	}
	ImGui::SetWindowSize(ImVec2(-1, -1));

	ImGui::SetWindowPos(ImVec2(pGUI->ScaleX(1500), pGUI->ScaleY(500)));
	ImGui::End();

	ImGui::PopStyleColor(3);
	ImGui::GetStyle().FrameBorderSize = style.FrameBorderSize;

}