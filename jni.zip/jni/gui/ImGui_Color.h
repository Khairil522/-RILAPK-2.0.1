#define MAX_COLORSTYLE 5

void SetColorStyle(uint8_t iStyle);

void ColorStyleDarkCharcoal();
void ColorStyleDirectX();
void ColorStyleDark();
void  FlameStyleColors();